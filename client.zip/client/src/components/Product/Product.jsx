import './Product.css'

const Product = ({name, price}) => {
    return (
        <span>{name} | {price}</span>
    )
}

export default Product