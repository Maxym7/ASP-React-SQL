
import { useState } from 'react'
import './CreateProduct.css'

const CreateProduct = ({onCreate}) => {

    const [name, setName] = useState('')
    const [price, setPrice] = useState(0)

    const handleInputChange = (e) => {
        const {name, value} = e.target
        if(name === 'name') setName(value)
        if(name === 'price') setPrice(value)
    }

    const handleSubmit = (e) => {
        e.preventDefault()

        onCreate({name, price})
      clearData()
    }

    const clearData = () => {
         setName('')
        setPrice(0)
    }


    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="name">Назва товару</label>
                    <input name="name" value={name}
                     type="text" placeholder="Напр., Ноутбук"
                     onChange={handleInputChange}
                     />
                </div>


                <div>
                    <label htmlFor="price">Ціна (UAH)</label>
                    <input name="price" value={price} type="number"
                      placeholder="Напр., 9999"
                       onChange={handleInputChange}
                      />
                </div>


                <button type="submit">Додати</button>
                <input type="reset" value="Очистити" onClick={() => {
                   clearData()
                }} />
            </form>
        </div>
    )
}

export default CreateProduct