import { useState } from 'react';
import './ProductList.css';

const ProductList = ({ products, onUpdate, onDelete }) => {
    const [editId, setEditId] = useState(null);
    const [newName, setNewName] = useState('');
    const [newPrice, setNewPrice] = useState(0);

    const handleUpdateClick = (product) => {
        setEditId(product.id);
        setNewName(product.name);
        setNewPrice(product.price);
    };

    const handleSave = (id) => {
        onUpdate(id, { name: newName, price: Number(newPrice) });
        setEditId(null);
        setNewName('');
        setNewPrice(0);
    };

    return (
        <div className="product-list">
            <ul>
                {products.map(product => (
                    <li key={product.id}>
                        
                        {editId === product.id ? (
                            <>
                                <input 
                                    type="text" 
                                    value={newName}
                                    onChange={(e) => setNewName(e.target.value)} 
                                />
                                <input 
                                    type="number" 
                                    value={newPrice}
                                    onChange={(e) => setNewPrice(e.target.value)} 
                                />
                                <button onClick={() => handleSave(product.id)}>Save</button>
                                <button onClick={() => setEditId(null)}>Cancel</button>
                            </>
                        ) : (
                            <>
                                <span>{product.name}</span> – 
                                <span>{product.price} Kč</span>
                                <button onClick={() => handleUpdateClick(product)}>Update</button>
                                <button onClick={() => onDelete(product.id)}>Delete</button>
                            </>
                        )}

                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ProductList;
