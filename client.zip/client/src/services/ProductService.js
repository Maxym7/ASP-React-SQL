import axios from "axios"

const URL = 'http://localhost:3000/products'

const http = axios.create({
    baseURL: URL,
    headers: {
        'Content-Type': 'application/json'
    }
})

const ProductService = {
    getAll: () => http.get('/'),
    getOne: (id) => http.get(`/${id}`),
    create: (data) => http.post(`/`, data),
    delete: (id) => http.delete(`/${id}`),
    update: (id, data) => http.put(`/${id}`, data),
    deleteAll: () => http.delete(`/`)
}

export default ProductService