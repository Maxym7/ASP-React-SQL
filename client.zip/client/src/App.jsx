import { useEffect, useState } from 'react'
import './App.css'
import CreateProduct from './components/CreateProduct/CreateProduct'
import ProductList from './components/ProductList/ProductList'
import ProductService from './services/ProductService'

function App() {
  const [products, setProducts] = useState([])

  useEffect(() => {

    fetchData()

  }, [])

  const handleDelete = async (id) => {
    await fetch(`https://localhost:7147/api/products/${id}`, {
      method: "DELETE"
    });

    setProducts(products.filter(p => p.id !== id));
  };


  const fetchData = async () => {
    const url = "https://localhost:7147/api/products"

    const response = await fetch(url)

    const data = await response.json()
    setProducts(data);

    console.log(data)

  }


  const handleUpdate = async (id, newProduct) => {
  const updated = {
    id: id,
    name: newProduct.name,
    price: newProduct.price
  };

  const response = await fetch(`https://localhost:7147/api/products/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(updated)
  });

  if (!response.ok) {
    console.error("Failed to update");
    return;
  }

  // update React state
  setProducts(products.map(p =>
    p.id === id ? updated : p
  ));
};


  const createProduct = async (product) => {
    const response = await fetch("https://localhost:7147/api/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(product)
    });

    if (!response.ok) {
      console.error("Failed to create product");
      return;
    }

    const created = await response.json();
    console.log("Created:", created);
  };




  return (
    <div className='app'>
      <CreateProduct onCreate={createProduct} />
      <ProductList
        products={products}
        onUpdate={handleUpdate}
        onDelete={handleDelete}
      />

    </div>

  )
}

export default App
