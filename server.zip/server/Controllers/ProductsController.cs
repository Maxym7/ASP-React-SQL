﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using server.Models;

namespace server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            return await _context.produtcs.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetItemById(int id)
        {
            var item = await _context.produtcs.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return item;
        }
        [HttpPost]
        public async Task<ActionResult<Product>> PostTodoItems(Product product)
        {
            _context.produtcs.Add(product);
            await _context.SaveChangesAsync();

            return product;
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateItemById(int id, Product product)
        {
            if (id != product.Id)
                return BadRequest("ID in URL does not match product ID");

            _context.Entry(product).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.produtcs.Any(x => x.Id == id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<ActionResult<Product>> DeleteItemById(int id)
        {
            Product? itemToDelete = await _context.produtcs.FindAsync(id);
            if (itemToDelete == null)
            {
                return NotFound();
            }
            _context.Remove(itemToDelete);
            _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
