﻿using Microsoft.EntityFrameworkCore;

namespace server.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Product> produtcs { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
    }
}
